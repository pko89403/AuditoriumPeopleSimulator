import sim.engine.*;
import sim.util.*;
import sim.field.continuous.*;
import sim.field.grid.DoubleGrid2D;
import sim.field.grid.IntGrid2D;
import sim.field.grid.SparseGrid2D;
import sim.field.network.*;


public class Audiences extends SimState{

	private static final long serialVersionUID = 1;
	
	public DoubleGrid2D trails;
	public SparseGrid2D humans;
	public IntGrid2D exhibition;
	public DoubleGrid2D toHome;
	public DoubleGrid2D toStuff;
	public IntGrid2D sites;
	
	public int numAudiences = 10000;
	public int numStuff = 300;
	
	public int gridWidth = 300;
	public int gridHeight = 310;
		
	public int centerWidth = gridWidth / 2;
	public int centerHeight = gridHeight / 2;
	
	public int doorLength = 10;
	public int HOME = 2;
	public int STUFF = 10;
	public int WALL = 1;
	public double AUDIENCE_RANDOMIZE = 0.5;
	public double INTEREST_CREATING = 0.01;
	
	public Bag Zone1;
	public Bag Zone2;
	public Bag Zone3;
	public Bag Zone4;
	
	public int getNumAudiences() { return numAudiences; }
	public void setNumAudiences(int val) { numAudiences = val;}
	
	public int getNumStuff() { return numStuff; }
	public void setNumStuff(int val) { numStuff = val;}
	
	public Double getAUDIENCE_RANDOMIZE() { return AUDIENCE_RANDOMIZE; }
	public void setAUDIENCE_RANDOMIZE(Double val){	AUDIENCE_RANDOMIZE = val; }
	
	public Double getINTEREST_CREATING() { return INTEREST_CREATING; }
	public void setINTEREST_CREATING(Double val){ INTEREST_CREATING = val; }
	
	public int homePosX;
	public int homePosY;
	public Int2D[] home;
	public Bag stuffLoc;
	
	public Int2D makeMap() // make walls and exhibition...
	{
		
		sites = new IntGrid2D(gridWidth, gridHeight, 0);
		toHome = new DoubleGrid2D(gridWidth, gridHeight, 0);
		toStuff = new DoubleGrid2D(gridWidth, gridHeight, 0);
		exhibition = new IntGrid2D(gridWidth, gridHeight, 0);
		stuffLoc = new Bag();
		
		
		for(int i=0; i < gridWidth; i++){
			exhibition.field[i][0] = WALL;
			exhibition.field[gridWidth-1][i] = WALL;
		}
		for(int i=0; i < gridHeight; i++){
			exhibition.field[0][i] = WALL;
		}
		
		home = new Int2D[4];
		for(int i=0; i< 4; i ++)
		{
			homePosX = random.nextInt(gridWidth-doorLength);
			homePosY = gridHeight-1;
			home[i] = new Int2D(homePosX,homePosY);
			
			// make home (start or end point)
			sites.field[homePosX][homePosY] = HOME;
			
			for(int j=0; j< gridWidth; j++)
			{
				exhibition.field[j][gridHeight-doorLength] = WALL;
			}
			
			for(int j=0; j< doorLength; j++)
			{
				exhibition.field[homePosX++][gridHeight-doorLength] = 0;
			}

		}
		// make Stuff for watching		
		for(int i=0; i< numStuff; i++)
		{	
			int x = random.nextInt(gridWidth-1);
			int y = random.nextInt(gridHeight-doorLength-1);
			sites.field[x][y] = STUFF;
			
			Int2D loc = new Int2D(x,y);
			stuffLoc.add(loc);
			
			for(int dx=-1; dx< 2; dx++)
				for(int dy= -1; dy < 2; dy++)
				{
					int px = x + dx; int py = y + dy;
					
					if(px <= 0 || py <= 0 || px >= gridWidth || py >= gridHeight) continue;
					
					sites.field[px][py] = STUFF;
				}
		}
		
		Int2D starting = new Int2D(centerWidth, centerHeight);
		
		return starting;
	}
	public Audiences(long seed)
	{
		super(seed);
	}
	
	public void start()
	{
		super.start();
		
		trails = new DoubleGrid2D(gridWidth, gridHeight);
		humans = new SparseGrid2D(gridWidth, gridHeight);
		
		Audience audience;
		
		
		Int2D start = makeMap();
		
		Zone1 = new Bag();
		Zone2 = new Bag();
		Zone3 = new Bag();
		Zone4 = new Bag();
		
		for ( int i=0; i < numAudiences; i++)
		{	
			
			audience = new Audience(random.nextInt(numStuff)+1);
			
			humans.setObjectLocation(audience, 
					start);
			
			schedule.scheduleRepeating(audience);
		}
	}
	
	public void ZoneCnt()
	{
		System.out.println(Zone1.numObjs + " : " + Zone2.numObjs + " : " + Zone3.numObjs + " : " + Zone4.numObjs);
		Zone1.clear(); Zone2.clear(); Zone3.clear(); Zone4.clear();
	}
	

	
	public static void main(String[] args)
	{

		SimState state = new Audiences(System.currentTimeMillis());

		state.start();

		do {
			if ( !state.schedule.step(state)) break;
			System.out.print(state.schedule.getSteps() + " ");
			((Audiences)state).ZoneCnt();
		} while( state.schedule.getSteps() < 10000 );
		
		state.finish();
		System.exit(0);
		
		
	}
}
